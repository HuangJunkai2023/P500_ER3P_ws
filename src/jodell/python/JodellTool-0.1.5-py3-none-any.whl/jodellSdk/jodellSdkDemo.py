import serial, time, ctypes
import serial.tools.list_ports
import modbus_tk.defines as cst
from modbus_tk import modbus_rtu


# SDK基础类
class ClawControl():
    def __init__(self):
        self.master = None
    
    def setMaster(self, master):
        self.master = master
    
    def getMaseter(self):
        return self.master

    def getS16(self, val):
        return ctypes.c_int16(val).value
    
    def getS8(self, val):
        return ctypes.c_int8(val).value

    def searchCom(self):
        """
            查询可用的串口
        """
        comList = []
        plist = list(serial.tools.list_ports.comports()) # 查询可用的串口
        for i in range(len(plist)):
            plist_0 = list(plist[i])
            comList.append(str(plist_0[0]))
        return comList

    def serialOperation(self, com, baudRate, state):
        """
            串口操作
            参数说明：
                com:串口号
                baudRate:波特率
                state:开关状态(打开:True, 关闭:False)
        """
        try:
            if state:
                self.master = modbus_rtu.RtuMaster(serial.Serial(port=com, baudrate=int(baudRate), bytesize=8, parity='N', stopbits=1))
                self.master.set_timeout(0.1)
                self.master.set_verbose(True)
            else:
                self.master._do_close()
            reVal = 1
            
        except Exception as exc:
            reVal = str(exc)
        
        return reVal
    
    def setBitValue(self, byte, index, val):
        """
            更改某个字节中某一位(Bit)的值
            参数说明：
                byte: 准备更改的字节原值
                index: 待更改位的序号,从右向左0开始,0-7为一个完整字节的8个位
                val: 目标位预更改的值,0或1
        """
        if val:
            return byte | (1 << index)
        else:
            return byte & ~(1 << index)

    def readRegisterData(self, slaveId, readMode, address, count):
        """
            状态查询
            参数说明：
                slaveId:夹爪站点id
                address:modbus寄存器地址
                readMode:modbus读取状态指令编号03或者04
                count:读取寄存器的个数
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, readMode, address, count) 
            return readBuf
        except Exception as exc:
            return str(exc)
    
    def writeDataToRegister(self, slaveId, address, sendCmdBuf):
        """
            将数据写入寄存器
            参数说明：
                slaveId:夹爪站点id
                address:modbus寄存器起始地址
                sendCmdBuf:写入的数据(格式为列表，列表长度代表写入寄存器个数)
        """
        if not self.master:
            return "通讯未连接"
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, address, output_value=sendCmdBuf) 
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def runWithoutParam(self, slaveId, cmdId):
        """
            无参数运行指令
            参数说明：
                slaveId:夹爪站点id
                cmdId:无参数指令编号
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [0x000B]
            sendCmdBuf[0] |= cmdId << 8
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def runWithParam(self, slaveId, pos, speed, torque):
        """
            有参数运行指令
            参数说明：
                slaveId:夹爪站点id
                pos:运行目标位置
                speed:运行中最大速度
                torque:抓取物体时的力矩
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x0009, 0x0000, 0x000]
            sendCmdBuf[1] = pos << 8
            sendCmdBuf[2] = speed | torque << 8   
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def getDeviceCurrentTemperature(self, slaveId):
        """
            获取设备当前温度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D3, 1)
            return [readBuf[0] >> 8]
        except Exception as exc:
            return str(exc)
    
    def getDeviceCurrentVoltage(self, slaveId):
        """
            获取设备当前电压
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D3, 1)
            return [readBuf[0] & 0xff]
        except Exception as exc:
            return str(exc)
    
    def readSoftwareVersion(self, slaveId):
        """
            读取软件版本
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x138C, 1)
            return ["V" + str(readBuf[0] >> 8) + "." + str(readBuf[0] & 0xff)]
        except Exception as exc:
            return str(exc)

    def changeSlaveId(self, oldId, newId):
        """
            修改夹爪站点ID
            参数说明：
                oldId:当前的id
                newId:修改后的id
        """
        if not self.master:
            return "通讯未连接"
        try: 
            sendCmdBuf = [newId]
            self.master.execute(oldId, cst.WRITE_MULTIPLE_REGISTERS, 0x138D, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def scanSlaveId(self, startId, stopId):
        """
            扫描连接的夹爪ID
            参数说明：
                startId:起始ID
                stopId:终止ID
        """
        if not self.master:
            return "通讯未连接"
        idList = []
        for myId in range(startId, stopId+1):
            try:
                self.master.execute(myId, cst.READ_INPUT_REGISTERS, 0x07D0, 1)
                idList.append(myId)
                time.sleep(0.02)
            except Exception as exc:
                pass
        return idList

    def changeBaudRate(self, slaveId, baudRate):
        """
            修改夹爪波特率
            参数说明：
                slaveId:夹爪站点ID
                baudRate:目标波特率编号(0:115200, 1:57600, 2:38400, 3:19200, 4:9600, 5:4800)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [baudRate]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x138E, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def writeCustomParam(self, slaveId, address, pos, speed, torque):
        """
            写入自定义参数
            参数说明：
                slaveId:夹爪站点ID
                address:modbus寄存器起始地址
                pos:预设位置
                speed:预设速度
                torque:预设力矩
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0, 0]
            sendCmdBuf[0] = int(pos) | (int(speed) << 8)
            sendCmdBuf[1] = int(torque)
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, address, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

# EPG类型SDK
class EpgClawControl(ClawControl):
    def __init__(self):
        super().__init__()
        self.clampState = {
            0: '手指正向指定位置移动', 
            1: '手指在张开检测到物体',
            2: '手指在闭合检测到物体',
            3: '手指已到达指定的位置，没有检测到物体'
        }
    
    def enableClamp(self, slaveId, state):
        """
            夹持使能
            参数说明：
                slaveId:夹爪站点id
                state:是否使能(使能:True, 去使能:False)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01] if state else [0x00]             
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def stopClaw(self, slaveId):
        """
            停止夹爪运动
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [0x0001]  
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FF, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def forceOpenBrake(self, slaveId, state):
        """
            强制打开抱闸
            参数说明：
                slaveId:夹爪站点ID
                state:开关状态(开:True,关:False)
        """
        if not self.master:
            return "通讯未连接"
        sendCmdBuf = [0x0001]  if state else [0x0000]
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FC, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def switchMode(self, slaveId, modeIndex):
        """
            选择模式
            参数说明：
                slaveId:夹爪站点ID
                modeIndex:模式编号(0:串口通讯模式, 1:IO模式)
        """
        if not self.master:
            return "通讯未连接"  
        if modeIndex == 0:  
            sendCmdBuf = [0x00]
        elif modeIndex == 1:                                        
            sendCmdBuf = [0x55] 
        else:
            sendCmdBuf = [0x00]
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FD, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readSoftwareVersion(self, slaveId):
        """
            读取软件版本
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x1388, 5)
            if readBuf[0] == 0:
                return ["V" + str(readBuf[4] >> 8) + "." + str(readBuf[4] & 0xff)]
            else:
                return ["V" + str(readBuf[0]) + "." + str(readBuf[4])]
        except Exception as exc:
            return str(exc)
    
    def getClampCurrentState(self, slaveId):
        """
            获取夹持端当前状态
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D0, 1)
            return [self.clampState[(readBuf[0] >> 6) & 0x03]]
        except Exception as exc:
            return str(exc)
    
    def getClampCurrentLocation(self, slaveId):
        """
            获取夹持端当前位置
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D1, 1)
            return [readBuf[0] >> 8]
        except Exception as exc:
            return str(exc)
    
    def getClampCurrentSpeed(self, slaveId):
        """
            获取夹持端当前速度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D2, 1)
            return [readBuf[0] & 0xff]
        except Exception as exc:
            return str(exc)
    
    def getClampCurrentTorque(self, slaveId):
        """
            获取夹持端当前力矩
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D2, 1)
            return [readBuf[0] >> 8]
        except Exception as exc:
            return str(exc)


# RG类型SDK
class RgClawControl(EpgClawControl):
    def __init__(self):
        super().__init__()


# EPG-HP类型SDK
class EpgHpClawControl(EpgClawControl):
    def __init__(self):
        super().__init__()


# RCG类型SDK
class RcgClawControl(EpgClawControl):
    def __init__(self):
        super().__init__()

    def switchMode(self, slaveId, modeIndex):
        """
            选择模式
            参数说明：
                slaveId:夹爪站点ID
                modeIndex:模式编号(0:串口通讯模式, 1:IO模式)
        """
        if not self.master:
            return "通讯未连接"  
    

# LEPG类型SDK
class LepgClawControl(EpgClawControl):
    def __init__(self):
        super().__init__()

    def enableCollision(self, slaveId, state):
        """
            碰撞使能
            参数说明：
                slaveId:夹爪站点ID
                state:使能状态(使能:True, 去使能:False)
        """
        if not self.master:
            return "通讯未连接"    
        sendCmdBuf = [0x55] if state else [0x00]        
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FE, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def setCollisionThreshold_1(self, slaveId, data):
        """
            设置碰撞阈值1
            参数说明：
                slaveId:夹爪站点ID
                data:碰撞阈值
        """
        if not self.master:
            return "通讯未连接"  
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FF, output_value=[data])
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def setCollisionThreshold_2(self, slaveId, data):
        """
            设置碰撞阈值2
            参数说明：
                slaveId:夹爪站点ID
                data:碰撞阈值
        """
        if not self.master:
            return "通讯未连接"  
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0400, output_value=[data])
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setCollisionThreshold_3(self, slaveId, data):
        """
            设置碰撞阈值3
            参数说明：
                slaveId:夹爪站点ID
                data:碰撞阈值
        """
        if not self.master:
            return "通讯未连接"  
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0401, output_value=[data])
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setDropThreshold(self, slaveId, data):
        """
            掉落检测阈值设置
            参数说明：
                slaveId:夹爪站点ID
                data:掉落检测阈值
        """
        if not self.master:
            return "通讯未连接"  
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0403, output_value=[data])
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def searchRange(self, slaveId):
        """
            搜索行程
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接" 
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0402, output_value=[0x01])
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def manualSavePosition(self, slaveId):
        """
            手动保存位置
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接" 
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0404, output_value=[0x01])
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setPreImpact(self, slaveId, data):
        """
            设定预撞击点
            参数说明：
                slaveId:夹爪站点ID
                data:设定预撞击点位置
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]             
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0405, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def setPreImpactSpeed(self, slaveId, data):
        """
            设定预撞击点速度
            参数说明：
                slaveId:夹爪站点ID
                data:预撞击点速度
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]             
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0406, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal


# EVS01类型SDK
class EvsClawControl_01(ClawControl):
    def __init__(self):
        super().__init__()
        self.deviceState = {
            0: "气压低于最低气压",
            1: "检测到工件，最低压力值已达到",
            2: "检测到工件，最高压力值已达到",
            3: "没有检测到对象，物体已丢失或未夹住脱落，或超时"
        }
    
    def enableDevice(self, slaveId, state):
        """
            设备使能
            参数说明：
                slaveId:夹爪站点id
                state:是否使能(使能:True, 去使能:False)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01] if state else [0x00]             
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def runWithoutParam(self, slaveId, cmdId):
        """
            无参数运行指令
            参数说明：
                slaveId:夹爪站点id
                cmdId: 无参数指令编号
        """
        pass

    def runWithParam(self, slaveId, pos, speed, torque):
        """
            有参数运行指令
            参数说明：
                slaveId:夹爪站点id
                pos:运行目标位置
                speed:运行中最大速度
                torque:抓取物体时的力矩
        """
        pass
    
    def writeCustomParam(self, slaveId, maxPressure, minPressure, timeout):
        """
            写入自定义参数
            参数说明：
                slaveId:夹爪站点ID
                maxPressure:最大气压值
                minPressure:最小气压值
                timeout:超时时间
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x00, 0x00]
            maxPressure = 100 - maxPressure
            minPressure = 100 - minPressure
            sendCmdBuf[0] = maxPressure << 8
            sendCmdBuf[1] = (minPressure << 8) | (timeout & 0xff)
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def startOrStopDevice(self, slaveId, mode, runFlag, breakState):
        """
            启动或停止设备
            参数说明：
                slaveId: 夹爪站点id
                mode: 运行模式,0为自动控制,1为高级模式
                runFlag: 启停标志, 0为停止, 1为运行
                breakState: 破真空标志, True为破真空, False为不破真空
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]
            sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 1, mode)
            sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 2, 1) if breakState else self.setBitValue(sendCmdBuf[0], 2, 0)
            sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 3, runFlag)
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def switchMode(self, slaveId, modeIndex):
        """
            选择模式
            参数说明：
                slaveId:夹爪站点ID
                modeIndex:模式编号(0:串口通讯模式, 1:IO模式)
        """
        if not self.master:
            return "通讯未连接"  
        if modeIndex == 0:  
            sendCmdBuf = [0x00]
        elif modeIndex == 1:                                        
            sendCmdBuf = [0x55] 
        else:
            sendCmdBuf = [0x00]       
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03ED, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readSoftwareVersion(self, slaveId):
        """
            读取软件版本
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x138C, 1)
            return ["V" + str(readBuf[0] >> 8) + "." + str(readBuf[0] & 0xff)]
        except Exception as exc:
            return str(exc)
    
    def getDeviceCurrentState(self, slaveId):
        """
            获取设备当前状态
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D0, 1)
            evsState = (readBuf[0] & 0xff) >> 6
            return [self.deviceState[evsState]]
        except Exception as exc:
            return str(exc)
    
    def getDeviceCurrentVacuumDegree(self, slaveId):
        """
            获取设备当前真空度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D2, 1)
            return [(readBuf[0] >> 8) - 100]
        except Exception as exc:
            return str(exc)

    
    def getDeviceCurrentTemperature(self, slaveId):
        """
            获取设备当前温度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D6, 1)
            return [readBuf[0] >> 8]
        except Exception as exc:
            return str(exc)
    
    def getDeviceCurrentVoltage(self, slaveId):
        """
            获取设备当前电压
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, 0x07D6, 1)
            return [readBuf[0] & 0xff]
        except Exception as exc:
            return str(exc)


# EVS08类型SDK
class EvsClawControl_08(EvsClawControl_01):
    def __init__(self):
        super().__init__()
    
    def writeCustomParam(self, slaveId, channelNo, maxPressure, minPressure, timeout):
        """
            写入自定义参数
            参数说明：
                slaveId:夹爪站点ID
                channelNo: 通道号(1: 通道1, 2:通道2)
                maxPressure:最大气压值
                minPressure:最小气压值
                timeout:超时时间
        """
        if not self.master:
            return "通讯未连接"
        try:
            if channelNo == 1:
                address = 0x03E9
            elif channelNo == 2:
                address = 0x03EB
            else:
                address = 0x03E9
            sendCmdBuf = [0x00, 0x00]
            maxPressure = 100 - maxPressure
            minPressure = 100 - minPressure
            setTime = int(timeout * 10)
            sendCmdBuf[0] = maxPressure << 8
            sendCmdBuf[1] = (minPressure << 8) | (setTime & 0xff)
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, address, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def startOrStopDevice(self, slaveId, mode, runFlag, channelIndex, breakState):
        """
            启动或停止设备
            参数说明：
                slaveId: 夹爪站点id
                mode: 运行模式,0为自动控制,1为高级模式
                runFlag: 启停标志, 0为停止, 1为运行
                channelIndex: 通道个数, 0为所有通道, 1为通道1, 2为通道2
                breakState: 破真空标志, True为破真空, False为不破真空
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]
            if channelIndex == 0:
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 1, mode)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 2, 1) if breakState else self.setBitValue(sendCmdBuf[0], 2, 0)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 3, runFlag)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 4, mode)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 5, 1) if breakState else self.setBitValue(sendCmdBuf[0], 5, 0)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 6, runFlag)
            elif channelIndex == 1:
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 1, mode)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 2, 1) if breakState else self.setBitValue(sendCmdBuf[0], 2, 0)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 3, runFlag)
            elif channelIndex == 2:
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 4, mode)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 5, 1) if breakState else self.setBitValue(sendCmdBuf[0], 5, 0)
                sendCmdBuf[0] = self.setBitValue(sendCmdBuf[0], 6, runFlag)
            else:
                pass
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def getDeviceCurrentState(self, slaveId, channelNo):
        """
            获取设备当前状态
            参数说明：
                slaveId:夹爪站点id
                channelNo: 通道号(1: 通道1, 2:通道2)
        """
        if not self.master:
            return "通讯未连接"
        try:
            if channelNo == 1:
                address = 0x07D0
            elif channelNo == 2:
                address = 0x07D3
            else:
                address = 0x07D0
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, address, 1)
            evsState = (readBuf[0] & 0xff) >> 6
            return [self.deviceState[evsState]]
        except Exception as exc:
            return str(exc)
    
    def getDeviceCurrentVacuumDegree(self, slaveId, channelNo):
        """
            获取设备当前真空度
            参数说明：
                slaveId:夹爪站点id
                channelNo: 通道号(1: 通道1, 2:通道2)
        """
        if not self.master:
            return "通讯未连接"
        try:
            if channelNo == 1:
                address = 0x07D2
            elif channelNo == 2:
                address = 0x07D5
            else:
                address = 0x07D2
            readBuf = self.master.execute(slaveId, cst.READ_INPUT_REGISTERS, address, 1)
            return [(readBuf[0] >> 8) - 100]
        except Exception as exc:
            return str(exc)


# ERG32类型SDK
class ErgClawControl(ClawControl):
    def __init__(self):
        super().__init__()
        self.clampState = {
            0: '初始状态',
            1: '手指正向指定位置移动',
            2: '手指在打开方向运动时，由于接触到物体已经停止',
            3: '手指在闭合方向运动时，由于接触到物体已经停止',
            4: '手指打开方向到达指定的位置，但没有检测到对象',
            5:'手指闭合方向到达指定的位置，但没有检测到对象'
        }
        self.rotateStatus = {
            0: '初始状态',
            1: '夹爪正向指定位置转动',
            2: '夹爪在顺时针方向运动时，由于受到阻力已经停止,拧紧',
            3: '夹爪在逆时针方向运动时，由于受到阻力已经停止，未拧开',
            4: '夹爪顺时针方向旋转到达指定的位置',
            5: '夹爪逆时针方向旋转到达指定的位置'
        }
    
    def enableClamp(self, slaveId, state):
        """
            夹持使能
            参数说明：
                slaveId:夹爪站点id
                state:是否使能(使能:True, 去使能:False)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01] if state else [0x00]             
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def enableRotate(self, slaveId, state):
        """
            夹爪旋转使能
            参数说明：
                slaveId:夹爪站点id
                state:是否使能(使能:True,去使能:False)
        """
        if not self.master:
            return "通讯未连接"  
        try:
            sendCmdBuf = [0x01] if state else [0x00]  
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def runWithParam(self, slaveId, pos, speed, torque):
        """
            有参数运行指令
            参数说明：
                slaveId:夹爪站点id
                pos:运行目标位置
                speed:运行中最大速度
                torque:抓取物体时的力矩
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x0000, 0x0000]
            sendCmdBuf[0] = speed << 8 | pos
            sendCmdBuf[1] = torque << 8 | 0x01   
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EA, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def rotateWithoutParam(self, slaveId, cmdId):
        """
            无参数旋转指令
            参数说明：
                slaveId:夹爪站点id
                cmdId:无参数指令编号
        """
        if not self.master:
            return "通讯未连接"      
        try:
            sendCmdBuf = [0x000B]
            sendCmdBuf[0] |= cmdId << 8
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def rotateWithParam(self, slaveId, angle, speed, torque, absState, cycleNum=0):
        """
            有参数旋转指令
            参数说明：
                slaveId:夹爪站点id
                angle:旋转角度
                speed:旋转时最大速度
                torque:旋转时的力矩
                absState:是否按绝对位置进行旋转(是:True, 否:False)
                cycleNum:圈数（配合绝对位置旋转使用）
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x0009, 0x0000, 0x0000, 0x0000]
            sendCmdBuf[0] = angle
            sendCmdBuf[1] = speed | torque << 8
            sendCmdBuf[2] = angle
            if absState:
                sendCmdBuf[3] = ctypes.c_int8(cycleNum).value << 8 | 0x01            
            else:
                sendCmdBuf[3] = 0x02

            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EC, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def scanSlaveId(self, startId, stopId):
        """
            扫描连接的夹爪ID
            参数说明：
                startId:起始ID
                stopId:终止ID
        """
        if not self.master:
            return "通讯未连接"
        idList = []
        for myId in range(startId, stopId+1):
            try:
                self.master.execute(myId, cst.READ_HOLDING_REGISTERS, 0x07D0, 4)
                idList.append(myId)
                myId += 1
                time.sleep(0.02)
            except Exception as exc:
                print(str(exc))
        return idList
    
    def changeBaudRate(self, slaveId, baudRate):
        """
            修改夹爪波特率
            参数说明：
                slaveId:夹爪站点ID
                baudRate:目标波特率编号(0:115200, 1:57600, 2:38400, 3:19200, 4:9600, 5:4800)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [baudRate]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x1395, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def getClampCurrentState(self, slaveId):
        """
            获取夹持端当前状态
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D0, 1)
            return [self.clampState[(readBuf[0] & 0xff) >> 5]]
        except Exception as exc:
            return str(exc)
    
    def getClampCurrentLocation(self, slaveId):
        """
            获取夹持端当前位置
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D2, 1)
            return [readBuf[0] & 0xff]
        except Exception as exc:
            return str(exc)
    
    def getClampCurrentSpeed(self, slaveId):
        """
            获取夹持端当前速度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D2, 1)
            return [readBuf[0] >> 8]
        except Exception as exc:
            return str(exc)
    
    def getClampCurrentTorque(self, slaveId):
        """
            获取夹持端当前力矩
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D3, 1)
            return [readBuf[0] >> 8]
        except Exception as exc:
            return str(exc)
    
    def getDeviceCurrentTemperature(self, slaveId):
        """
            获取设备当前温度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D8, 1)
            return [readBuf[0] >> 8]
        except Exception as exc:
            return str(exc)
    
    def getDeviceCurrentVoltage(self, slaveId):
        """
            获取设备当前电压
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D8, 1)
            return [readBuf[0] & 0xff]
        except Exception as exc:
            return str(exc)
    
    def readSoftwareVersion(self, slaveId):
        """
            查询软件版本
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x9101, 3)
            return ["V" + str(readBuf[0]) + "." + str(readBuf[1]) +"." + str(readBuf[2])]
        except Exception as exc:
            return str(exc)

    def stopClampMotion(self, slaveId):
        """
            停止夹持运动
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [0x0011]  
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def getRotateCurrentState(self, slaveId):
        """
            获取旋转端当前状态
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D1, 1)
            return [self.rotateStatus[(readBuf[0] & 0xff) >> 5]]
        except Exception as exc:
            return str(exc)
    
    def getAbsoluteAngle(self, slaveId):
        """
            获取旋转端绝对角度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D4, 1)
            return [self.getS16(readBuf[0])]
        except Exception as exc:
            return str(exc)
    
    def getRelativeAngle(self, slaveId):
        """
            获取旋转端相对角度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D7, 1)
            return [self.getS16(readBuf[0])]
        except Exception as exc:
            return str(exc)
    
    def getAbsoluteNumberOfTurns(self, slaveId):
        """
            获取旋转端绝对圈数
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D6, 1)
            return [self.getS8(readBuf[0] >> 8)]
        except Exception as exc:
            return str(exc)
    
    def getRotateCurrentSpeed(self, slaveId):
        """
            获取旋转端当前速度
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D5, 1)
            return [readBuf[0] & 0xff]
        except Exception as exc:
            return str(exc)
    
    def getRotateCurrentTorque(self, slaveId):
        """
            获取旋转端当前力矩
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D5, 1)
            return [readBuf[0] >> 8]
        except Exception as exc:
            return str(exc)
    
    def stopRotateMotion(self, slaveId):
        """
            停止旋转运动
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [0x0011]  
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def forceOpenBrake(self, slaveId, state):
        """
            强制打开抱闸
            参数说明：
                slaveId:夹爪站点ID
                state:开关状态(开:True,关:False)
        """
        if not self.master:
            return "通讯未连接"
        sendCmdBuf = [0x0001] if state else [0x0000]
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x1397, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setRotateToZero(self, slaveId, angle):
        """
            旋转端设置零点偏置
            参数说明：
                slaveId:夹爪站点ID
                angle:对零角度
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [self.getS16(angle)]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0410, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def switchMode(self, slaveId, modeIndex):
        """
            选择模式
            参数说明：
                slaveId:夹爪站点ID
                modeIndex:模式编号(0:串口通讯模式, 1:IO模式)
        """
        if not self.master:
            return "通讯未连接"  
        if modeIndex == 0:  
            sendCmdBuf = [0x00]
        elif modeIndex == 1:                                        
            sendCmdBuf = [0x55] 
        else:
            sendCmdBuf = [0x00]
        try:
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0413, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal


# ERG08类型SDK
class ErgClawControl_08(ErgClawControl):
    def __init__(self):
        super().__init__()
        self.clampState = {
            0: '手指正向指定位置移动', 
            1: '手指在张开检测到物体', 
            2: '手指在闭合检测到物体', 
            3: '手指已到达指定的位置，没有检测到物体'
        }
        self.rotateStatus = {
            0: '初始状态',
            1: '夹爪正向指定位置转动',
            2: '夹爪在顺时针方向运动时，由于受到阻力已经停止，拧紧',
            3: '夹爪在逆时针方向运动时，由于受到阻力已经停止，未拧开',
            4: '夹爪顺时针方向旋转到达指定的位置',
            5: '夹爪逆时针方向旋转到达指定的位置'
        }

    def changeBaudRate(self, slaveId, baudRate):
        """
            修改夹爪波特率
            参数说明：
                slaveId:夹爪站点ID
                baudRate:目标波特率编号(0:115200, 1:57600, 2:38400, 3:19200, 4:9600, 5:4800)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [baudRate]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x138E, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def stopClampMotion(self, slaveId):
        """
            停止夹持运动
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"
    
    def stopRotateMotion(self, slaveId):
        """
            停止旋转运动
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [0x0001]  
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def getClampCurrentState(self, slaveId):
        """
            获取夹持端当前状态
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D0, 1)
            return [self.clampState[(readBuf[0] & 0xff) >> 6]]
        except Exception as exc:
            return str(exc)
    
    def readSoftwareVersion(self, slaveId):
        """
            查询软件版本
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x138C, 1)
            return ["V" + str(readBuf[0] >> 8) + "." + str(readBuf[0] & 0xff)]
        except Exception as exc:
            return str(exc)
    
    def switchMode(self, slaveId, modeIndex):
        """
            选择模式
            参数说明：
                slaveId:夹爪站点ID
                modeIndex:模式编号(0:串口通讯模式, 1:IO模式)
        """
        if not self.master:
            return "通讯未连接"
    
    def forceOpenBrake(self, slaveId, state):
        """
            强制打开抱闸
            参数说明：
                slaveId:夹爪站点ID
                state:开关状态(开:True,关:False)
        """
        if not self.master:
            return "通讯未连接"


# ZRG类型SDK
class ZrgClawControl(ErgClawControl_08):
    def __init__(self):
        super().__init__()
        self.zAxisState = {
            0: '设备正向指定位置移动', 
            1: '设备在上升过程中检测到物体', 
            2: '设备在下降过程中检测到物体', 
            3: '设备已到达指定的位置，没有检测到物体'
        }
    
    def enableZAxis(self, slaveId, state, mode):
        """
            Z轴使能
            参数说明：
                slaveId:夹爪站点id
                state:是否使能(使能:True, 去使能:False)
                mode:是否跟随(跟随模式:True, 非跟随模式:False)
        """
        if not self.master:
            return "通讯未连接"  
        try:
            if state:
                sendCmdBuf = [0x05 if mode else 0x01]
            else:
                sendCmdBuf = [0x04 if mode else 0x00]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0BB8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def runZAxisWithoutParam(self, slaveId, cmdId, mode):
        """
            无参数旋转指令
            参数说明：
                slaveId:夹爪站点id
                cmdId:无参数指令编号
                mode:是否跟随(跟随模式:True, 非跟随模式:False)
        """
        if not self.master:
            return "通讯未连接"      
        try:
            sendCmdBuf = [0x000D if mode else 0x000B]
            sendCmdBuf[0] |= cmdId << 8
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0BB8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def runZAxisWithParam(self, slaveId, pos, speed, torque, mode):
        """
            有参数运行指令
            参数说明：
                slaveId:夹爪站点id
                pos:运行目标位置
                speed:运行中最大速度
                torque:抓取物体时的力矩
                mode:是否跟随(跟随模式:True, 非跟随模式:False)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x000D if mode else 0x0009, 0x0000, 0x0000]
            sendCmdBuf[1] = pos
            sendCmdBuf[2] = torque << 8 | speed
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0BB8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setElecGearRatio(self, slaveId, data):
        """
            设置电子齿轮比
            参数说明：
                slaveId:夹爪站点id
                data:电子齿轮比数据
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0BCC, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def readSoftwareVersionOfZAxis(self, slaveId):
        """
            查询Z轴软件版本
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x232C, 1)
            return ["V" + str(readBuf[0] >> 8) + "." + str(readBuf[0] & 0xff)]
        except Exception as exc:
            return str(exc)


class ElsClawControl(ClawControl):
    def __init__(self):
        super().__init__()
    
    def restartDevice(self, slaveId):
        """
            设备重启
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]         
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def saveParam(self, slaveId):
        """
            参数保存
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def restoreDefault(self, slaveId):
        """
            恢复默认
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EA, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def chooseSignalSource(self, slaveId, data):
        """
            信号源选择
            参数说明：
                slaveId:夹爪站点id
                data:写入的数据(1:485控制, 0:IO控制)
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EB, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def chooseUserControlMode(self, slaveId, data):
        """
            用户控制模式选择
            参数说明：
                slaveId:夹爪站点id
                data:写入的数据(1:点动, 0:正常)
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EC, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def enableDevice(self, slaveId, state):
        """
            设备使能
            参数说明：
                slaveId:夹爪站点id
                state:使能状态(1:使能 0:失能)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [state]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03ED, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def resetDevice(self, slaveId):
        """
            清除故障/设备复位
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EE, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def controlAction(self, slaveId, state):
        """
            动作控制
            参数说明：
                slaveId:夹爪站点id
                state:动作状态(
                    0:执行点0命令, 
                    1:执行点1命令, 
                    2:执行点2命令, 
                    3:执行点3命令, 
                    4:相对运动模式, 
                    5:执行非可存位置
                )
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [state]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EF, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def chooseMotorDirdction(self, slaveId, state):
        """
            选择运动方向
            参数说明：
                slaveId:夹爪站点ID
                state:运动方向(1:正向运动, 2:触发相对/点动运动-)
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [state]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F0, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setPointPosition(self, slaveId, pointNo, data):
        """
            设置预设点位置
            参数说明：
                slaveId:夹爪站点ID
                pointNo:预设点序号, 0:预设点0, 1:预设点1, 2:预设点2, 3:预设点3, 4:非可存点
                data:位置数据, 输入范围:0~65535, 单位:0.01mm
        """
        if not self.master:
            return "通讯未连接"    
        try:
            address = 0x03F1 + pointNo * 3
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, address, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readPointPosition(self, slaveId, pointNo):
        """
            获取预设点位置
            参数说明：
                slaveId:夹爪站点id
                pointNo:预设点序号, 0:预设点0, 1:预设点1, 2:预设点2, 3:预设点3, 4:非可存点
            返回值说明：
                位置数据, 单位:mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            address = 0x03F1 + pointNo * 3
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, address, 1)
            return [readBuf[0] * 0.01]
        except Exception as exc:
            return str(exc)
    
    def setPointSpeed(self, slaveId, pointNo, data):
        """
            设置预设点速度
            参数说明：
                slaveId:夹爪站点ID
                pointNo:预设点序号, 0:预设点0, 1:预设点1, 2:预设点2, 3:预设点3, 4:非可存点
                data:速度数据, 输入范围:0~65535, 单位:0.01mm/s
        """
        if not self.master:
            return "通讯未连接"    
        try:
            address = 0x03F2 + pointNo * 3
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, address, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readPointSpeed(self, slaveId, pointNo):
        """
            获取预设点速度
            参数说明：
                slaveId:夹爪站点id
                pointNo:预设点序号, 0:预设点0, 1:预设点1, 2:预设点2, 3:预设点3, 4:非可存点
            返回值说明：
                速度数据, 单位:mm/s
        """
        if not self.master:
            return "通讯未连接"
        try:
            address = 0x03F2 + pointNo * 3
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, address, 1)
            return [readBuf[0] * 0.01]
        except Exception as exc:
            return str(exc)
    
    def setPointTorque(self, slaveId, pointNo, data):
        """
            设置预设点力矩
            参数说明：
                slaveId:夹爪站点ID
                pointNo:预设点序号, 0:预设点0, 1:预设点1, 2:预设点2, 3:预设点3, 4:非可存点
                data:力矩数据, 输入范围:0~100, 单位:N
        """
        if not self.master:
            return "通讯未连接"    
        try:
            address = 0x03F3 + pointNo * 3
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, address, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readPointTorque(self, slaveId, pointNo):
        """
            获取预设点力矩
            参数说明：
                slaveId:夹爪站点id
                pointNo:预设点序号, 0:预设点0, 1:预设点1, 2:预设点2, 3:预设点3, 4:非可存点
            返回值说明：
                力矩数据, 单位:N
        """
        if not self.master:
            return "通讯未连接"
        try:
            address = 0x03F3 + pointNo * 3
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, address, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def setRelativeMotionDistance(self, slaveId, data):
        """
            设置相对运动距离
            参数说明：
                slaveId:夹爪站点ID
                data:位置数据, 输入范围:0~65535, 单位:0.01mm
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0400, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readRelativeMotionDistance(self, slaveId):
        """
            获取相对运动距离
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                位置数据, 单位:0.01mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x0400, 1)
            return [readBuf[0] * 0.01]
        except Exception as exc:
            return str(exc)
    
    def setJogStepValue(self, slaveId, data):
        """
            设置点动步进值
            参数说明：
                slaveId:夹爪站点ID
                data:位置数据, 输入范围:0~65535, 单位:0.01mm
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0401, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readJogStepValue(self, slaveId):
        """
            获取点动步进值
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                位置数据, 单位:0.01mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x0401, 1)
            return [readBuf[0] * 0.01]
        except Exception as exc:
            return str(exc)
    
    def setDecelerationPercentageOfPosition(self, slaveId, data):
        """
            设置减速段位置百分比
            参数说明：
                slaveId:夹爪站点ID
                data:位置数据, 输入范围:0~100
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0402, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readDecelerationPercentageOfPosition(self, slaveId):
        """
            获取减速段位置百分比
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                减速段位置百分比
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x0402, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def setDecelerationPercentageOfSpeed(self, slaveId, data):
        """
            设置减速段速度百分比
            参数说明：
                slaveId:夹爪站点ID
                data:速度数据, 输入范围:0~100
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0403, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readDecelerationPercentageOfSpeed(self, slaveId):
        """
            获取减速段速度百分比
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                减速段速度百分比
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x0403, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def setDecelerationDirection(self, slaveId, data):
        """
            设置减速段作用方向
            参数说明：
                slaveId:夹爪站点ID
                data:位置数据(
                    0:取消减速
                    1:推方向
                    2:拉方向
                    3:双方向
                )
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0404, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readDecelerationDirection(self, slaveId):
        """
            获取减速段作用方向
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                0:取消减速
                1:推方向
                2:拉方向
                3:双方向
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x0404, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def setIoForcedOutput(self, slaveId, data):
        """
            设置IO强制输出
            参数说明：
                slaveId:夹爪站点ID
                data:IO强制输出数据
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0405, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def readIoForcedOutput(self, slaveId):
        """
            获取IO强制输出
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                IO强制输出状态
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x0405, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def forcedControlBrake(self, slaveId, data):
        """
            抱闸强制打开
            参数说明：
                slaveId:夹爪站点ID
                data: 1:强制打开, 0:恢复正常
        """
        if not self.master:
            return "通讯未连接"    
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0406, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def changeSlaveId(self, oldId, newId):
        """
            修改设备从站地址
            参数说明：
                oldId:当前的id
                newId:修改后的id(输入范围:1~247)
        """
        if not self.master:
            return "通讯未连接"
        try: 
            sendCmdBuf = [newId]
            self.master.execute(oldId, cst.WRITE_MULTIPLE_REGISTERS, 0x0246, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def changeBaudRate(self, slaveId, baudRate):
        """
            修改设备波特率
            参数说明：
                slaveId:夹爪站点ID
                baudRate:目标波特率编号(0:9600, 1:19200, 2:38400, 3:115200)
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [baudRate]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0245, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def getDeviceRunState(self, slaveId):
        """
            获取设备运行状态
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                设备运行状态
                1:空闲状态
                4:使能状态
                7:故障状态
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D0, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getDeviceActionState(self, slaveId):
        """
            获取设备动作状态
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                设备动作状态
                0:过渡状态
                2:搜索大端行程
                5:搜索小端行程
                8:动作运行中
                9:动作受阻
                10:动作到位 
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D1, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)

    def getDeciveCurrentLocation(self, slaveId):
        """
            获取设备当前位置
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                显示当前行程位置, 单位:0.01mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D2, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getDeciveCurrentSpeed(self, slaveId):
        """
            获取设备当前速度
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                显示当前速度, 单位:0.01mm/s
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D3, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
  
    def getDeviceCurrentTorque(self, slaveId):
        """
            获取设备当前力矩
            参数说明：
                slaveId:夹爪站点id
            返回值说明：
                力矩数据, 单位:N
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D4, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getDeviceErrorState(self, slaveId):
        """
            获取设备故障状态
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                bit0: 电机故障
                bit1: 行程错误
                bit2: 搜索超时
                bit3: 移动超时
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D5, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getMotorErrorState(self, slaveId):
        """
            获取电机故障状态
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                bit0: 过压故障
                bit1: 欠压故障
                bit2: 过温故障
                bit3: 编码器故障
                bit4: 预驱故障
                bit5: 采样故障
                bit6: 算法超时故障
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D6, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getIoInputMonitoring(self, slaveId):
        """
            获取IO输入监测
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                转为2进制, 检测IO输入(1bit对应1信号)
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D7, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getIoOutputMonitoring(self, slaveId):
        """
            获取IO输出监测
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                转为2进制, 检测IO输出(1bit对应1信号)
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D8, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    

class IntegrationEpgClawControl(ClawControl):
    def __init__(self):
        super().__init__()
    
    def restartDevice(self, slaveId):
        """
            设备重启
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]         
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def saveParam(self, slaveId):
        """
            参数保存
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def restoreDefault(self, slaveId):
        """
            恢复默认
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EA, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def encoderCalibration(self, slaveId):
        """
            编码器校正
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EC, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def zeroPointAlignment(self, slaveId):
        """
            零点对齐
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03ED, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def forcedControlBrake(self, slaveId, data):
        """
            抱闸强制打开
            参数说明：
                slaveId:夹爪站点ID
                data: 1:强制打开, 0:恢复正常
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EE, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def ioOutputForrced(self, slaveId, data):
        """
            IO输出强制
            参数说明：
                slaveId:夹爪站点ID
                data: 1:开启IO输出强制, 0:关闭IO输出强制
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EF, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setCloseSpeed(self, slaveId, data):
        """
            设置夹持动作速度
            参数说明：
                slaveId:夹爪站点ID
                data: 夹持动作速度, 输入范围:50~255
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F0, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setOpenSpeed(self, slaveId, data):
        """
            设置打开动作速度
            参数说明：
                slaveId:夹爪站点ID
                data: 打开动作速度, 输入范围:50~255
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F1, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setCloseTorque(self, slaveId, data):
        """
            夹持力设定
            参数说明：
                slaveId:夹爪站点ID
                data: 夹持力, 单位N
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F2, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setOpenTorque(self, slaveId, data):
        """
            打开力设定
            参数说明：
                slaveId:夹爪站点ID
                data: 打开力, 单位N
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F3, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def setCloseWidth(self, slaveId, data):
        """
            设定夹持宽度
            参数说明：
                slaveId:夹爪站点ID
                data: 夹持宽度, 单位0.1mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F4, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setOpenWidth(self, slaveId, data):
        """
            设定打开宽度
            参数说明：
                slaveId:夹爪站点ID
                data: 打开宽度, 单位0.1mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F5, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setTargetWidth(self, slaveId, data):
        """
            设定目标宽度
            参数说明：
                slaveId:夹爪站点ID
                data: 目标宽度, 单位0.1mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F6, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setAllowableErrorForTargetWidth(self, slaveId, data):
        """
            设定目标宽度容许误差
            参数说明：
                slaveId:夹爪站点ID
                data: 目标宽度容许误差, 单位0.1mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F7, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setMaximumFingerSpacing(self, slaveId, data):
        """
            设定最大手指间距
            参数说明：
                slaveId:夹爪站点ID
                data: 最大手指间距, 单位0.1mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setMinimumFingerSpacing(self, slaveId, data):
        """
            设定最小手指间距
            参数说明：
                slaveId:夹爪站点ID
                data: 最小手指间距, 单位0.1mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def openGripper(self, slaveId):
        """
            打开夹爪
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FA, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def closeGripper(self, slaveId):
        """
            关闭夹爪
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FB, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def clearFault(self, slaveId):
        """
            清除故障
            参数说明：
                slaveId:夹爪站点ID
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FC, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setModbusSlaveAddress(self, slaveId, data):
        """
            设定Modbus站号
            参数说明：
                slaveId:夹爪站点ID
                data: Modbus站号, 输入范围: 0~255
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FE, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setModbusBaudRate(self, slaveId, data):
        """
            设定Modbus波特率
            参数说明：
                slaveId:夹爪站点ID
                data: Modbus波特率
                      0: 9600
                      1: 19200
                      2: 38400
                      3: 115200
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FF, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setCommandSource(self, slaveId, data):
        """
            设定命令源
            参数说明：
                slaveId:夹爪站点ID
                data: 命令源
                      0: IO模式
                      1: 485模式
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0400, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def getIoInputMonitoring(self, slaveId):
        """
            获取IO输入监测
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                转为2进制, 检测IO输入(1bit对应1信号)
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D1, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getIoOutputMonitoring(self, slaveId):
        """
            获取IO输出监测
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                转为2进制, 检测IO输出(1bit对应1信号)
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D0, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getDeviceState(self, slaveId):
        """
            获取设备状态
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                0x00: 未初始化
                0x01: 等待回零
                0x02: 回零中
                0x03: 就绪
                0x04: 打开中
                0x05: 打开到位
                0x06: 闭合中
                0x07: 夹持成功
                0x08: 夹持为空
                0x09: 夹持掉落
                0x0A: 故障
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D2, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getDeviceFault(self, slaveId):
        """
            获取设备故障码
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                0x00: 无故障
                0x01: 回零超时
                0x02: 打开超时
                0x04: 零点数据故障
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D3, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getMotorState(self, slaveId):
        """
            获取电机状态
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                0x00: 就绪
                0x01: 充电中
                0x02: 对齐中
                0x03: 等待力矩恢复
                0x04: 运行中
                0x05: 等待抱闸关闭
                0x06: 故障
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D4, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getMotorFault(self, slaveId):
        """
            获取电机故障码
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                0x00: 无故障
                0x01: 过压故障
                0x02: 欠压故障
                0x04: 编码器故障
                0x08: 过温故障
                0x20: 预驱故障
                0x80: 对齐数据故障
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D5, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getFingerSpacing(self, slaveId):
        """
            获取手指间距
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                手指间距, 单位: 0.1mm
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D6, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)


class EpgLClawControl(IntegrationEpgClawControl):
    def __init__(self):
        super().__init__()
    
    def encoderCalibration(self, slaveId):
        """
            编码器校正
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"     
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EB, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def zeroPointAlignment(self, slaveId):
        """
            零点对齐
            参数说明：
                slaveId:夹爪站点id
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [0x01]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EC, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def enableDevice(self, slaveId, data):
        """
            使能夹爪
            参数说明：
                slaveId:夹爪站点id
                data:1：使能夹爪; 0：失能夹爪
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FD, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def selectIndex(self, slaveId, data):
        """
            配方索引
            参数说明：
                slaveId:夹爪站点id
                data: 写0~1
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03FE, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setModbusSlaveAddress(self, slaveId, data):
        """
            设定Modbus站号
            参数说明：
                slaveId:夹爪站点ID
                data: Modbus站号, 输入范围: 1~247
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0BBA, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setModbusBaudRate(self, slaveId, data):
        """
            设定Modbus波特率
            参数说明：
                slaveId:夹爪站点ID
                data: 波特率, 输入范围: 9600~921600
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data & 0xFFFF, data >> 16]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0BB8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setCommandSource(self, slaveId, data):
        """
            设定命令源
            参数说明：
                slaveId:夹爪站点ID
                data: 命令源
                      0: 主通讯模式
                      1: 485模式
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x0BBB, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal


class ErgClawControl_2(ClawControl):
    def __init__(self):
        super().__init__()

    def controlDevice(self, slaveId, data):
        """
            控制设备
            参数说明：
                slaveId:夹爪站点ID
                data: 控制字
                      0: 去使能
                      1: 使能
                      2: 打开夹爪
                      3: 闭合夹爪
                      4: 旋转夹爪(旋转点1)
                      5: 旋转夹爪(旋转点2)
                      6: 旋转夹爪(旋转点3)
                      7: 复位设备
                      8: 重启设备
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03E9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setClawOpenSpeed(self, slaveId, data):
        """
            设置夹爪打开速度
            参数说明：
                slaveId:夹爪站点ID
                data: 夹爪打开速度, 单位: 0.01mm/s
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EA, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setClawCloseSpeed(self, slaveId, data):
        """
            设置夹爪闭合速度
            参数说明：
                slaveId:夹爪站点ID
                data: 夹爪闭合速度, 单位: 0.01mm/s
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EB, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def setClawOpenTorque(self, slaveId, data):
        """
            设置夹爪打开力矩
            参数说明：
                slaveId:夹爪站点ID
                data: 夹爪打开力矩, 范围: 50-300, 单位: mA
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03EC, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setClawCloseTorque(self, slaveId, data):
        """
            设置夹爪闭合力矩
            参数说明：
                slaveId:夹爪站点ID
                data: 夹爪闭合力矩, 范围: 50-300, 单位: mA
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03ED, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setRotateSpeed(self, slaveId, data):
        """
            设置旋转速度 
            参数说明：
                slaveId:夹爪站点ID
                data: 旋转速度, 范围: 100-10000, 单位: 0.1°/s
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F0, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setRotateTorque(self, slaveId, data):
        """
            设置旋转力矩
            参数说明：
                slaveId:夹爪站点ID
                data: 旋转力矩, 范围: 300-500, 单位: mA
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F1, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setRotatePosition_1(self, slaveId, data):
        """
            设置旋转位置1(绝对角度)
            参数说明：
                slaveId:夹爪站点ID
                data: 旋转角度, 范围: 0-65535, 单位: 0.1°
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F2, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setRotatePosition_2(self, slaveId, data):
        """
            设置旋转位置2(绝对角度)
            参数说明：
                slaveId:夹爪站点ID
                data: 旋转角度, 范围: 0-65535, 单位: 0.1°
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F3, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setRotatePosition_3(self, slaveId, data):
        """
            设置旋转位置3(绝对角度)
            参数说明：
                slaveId:夹爪站点ID
                data: 旋转角度, 范围: 0-65535, 单位: 0.1°
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F4, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def setRotateZeroOffset(self, slaveId, data):
        """
            设置旋转零点偏移
            参数说明：
                slaveId:夹爪站点ID
                data: 旋转角度, 范围: 0-65535, 单位: 0.1°
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F5, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setCommandSource(self, slaveId, data):
        """
            设置命令源
            参数说明：
                slaveId:夹爪站点ID
                data: 命令源
                      0: 485模式
                      1: IO模式
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F7, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def setModbusSlaveAddress(self, slaveId, data):
        """
            设定Modbus站号
            参数说明：
                slaveId:夹爪站点ID
                data: Modbus站号, 输入范围: 1~247
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F8, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal
    
    def setModbusBaudRate(self, slaveId, data):
        """
            设定Modbus波特率
            参数说明：
                slaveId:夹爪站点ID
                data: 1: 9600
                      2: 38400
                      3: 115200
        """
        if not self.master:
            return "通讯未连接"
        try:
            sendCmdBuf = [data]           
            self.master.execute(slaveId, cst.WRITE_MULTIPLE_REGISTERS, 0x03F9, output_value=sendCmdBuf)
            reVal = 1
        except Exception as exc:
            reVal = str(exc)
        return reVal

    def getDeviceState(self, slaveId):
        """
            获取设备状态
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                0: 初始状态
                1: 空闲（待机）状态
                2: 运行状态
                3: 故障状态
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D0, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
    
    def getDeviceRunState(self, slaveId):
        """
            获取设备动作状态
            参数说明：
                slaveId:夹爪站点id
            返回值说明:
                1: 动作执行中
                2: 设备使能完成
                3: 打开动作按指定要求已完成
                4: 打开动作过程中受阻而停止
                5: 夹持动作按指定要求已完成
                6: 夹持动作过程中受阻而停止
                7: 旋转点1动作按指定要求已完成
                8: 旋转点1动作过程中受阻而停止
                9: 旋转点2动作按指定要求已完成
                10: 旋转点2动作过程中受阻而停止
                11: 旋转点3动作按指定要求已完成
                12: 旋转点3动作过程中受阻而停止
                13: 夹持过程中物体中途掉落
                14: 动作执行过程中出错而停止
        """
        if not self.master:
            return "通讯未连接"
        try:
            readBuf = self.master.execute(slaveId, cst.READ_HOLDING_REGISTERS, 0x07D1, 1)
            return [readBuf[0]]
        except Exception as exc:
            return str(exc)
